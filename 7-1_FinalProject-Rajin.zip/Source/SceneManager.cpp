///////////////////////////////////////////////////////////////////////////////
// SceneManager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//  Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
//
//  ---- Student submission version ----
//  This version keeps the original helper methods and installs a polished
//  scene in PrepareScene()/RenderScene(): floor + table + bowl + spoon + bottle.
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>
#include <iostream>

// declaration of global variables
namespace
{
    const char* g_ModelName = "model";
    const char* g_ColorValueName = "objectColor";
    const char* g_TextureValueName = "objectTexture";
    const char* g_UseTextureName = "bUseTexture";
    const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 ***********************************************************/
SceneManager::~SceneManager()
{
    m_pShaderManager = NULL;
    delete m_basicMeshes;
    m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
    int width = 0;
    int height = 0;
    int colorChannels = 0;
    GLuint textureID = 0;

    stbi_set_flip_vertically_on_load(true);
    unsigned char* image = stbi_load(filename, &width, &height, &colorChannels, 0);

    if (image)
    {
        std::cout << "Successfully loaded image:" << filename
            << ", width:" << width << ", height:" << height
            << ", channels:" << colorChannels << std::endl;

        glGenTextures(1, &textureID);
        glBindTexture(GL_TEXTURE_2D, textureID);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (colorChannels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (colorChannels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0);

        m_textureIDs[m_loadedTextures].ID = textureID;
        m_textureIDs[m_loadedTextures].tag = tag;
        m_loadedTextures++;

        return true;
    }

    std::cout << "Could not load image:" << filename << std::endl;
    return false;
}

/***********************************************************
 *  BindGLTextures()
 ***********************************************************/
void SceneManager::BindGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
    }
}

/***********************************************************
 *  DestroyGLTextures()
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        glGenTextures(1, &m_textureIDs[i].ID);
    }
}

/***********************************************************
 *  FindTextureID()
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
    int textureID = -1;
    int index = 0;
    bool bFound = false;

    while ((index < m_loadedTextures) && (bFound == false))
    {
        if (m_textureIDs[index].tag.compare(tag) == 0)
        {
            textureID = m_textureIDs[index].ID;
            bFound = true;
        }
        else
            index++;
    }

    return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
    int textureSlot = -1;
    int index = 0;
    bool bFound = false;

    while ((index < m_loadedTextures) && (bFound == false))
    {
        if (m_textureIDs[index].tag.compare(tag) == 0)
        {
            textureSlot = index;
            bFound = true;
        }
        else
            index++;
    }

    return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
    if (m_objectMaterials.size() == 0)
    {
        return(false);
    }

    int index = 0;
    bool bFound = false;
    while ((index < (int)m_objectMaterials.size()) && (bFound == false))
    {
        if (m_objectMaterials[index].tag.compare(tag) == 0)
        {
            bFound = true;
            material.ambientColor = m_objectMaterials[index].ambientColor;
            material.ambientStrength = m_objectMaterials[index].ambientStrength;
            material.diffuseColor = m_objectMaterials[index].diffuseColor;
            material.specularColor = m_objectMaterials[index].specularColor;
            material.shininess = m_objectMaterials[index].shininess;
        }
        else
        {
            index++;
        }
    }

    return(true);
}

/***********************************************************
 *  SetTransformations()
 ***********************************************************/
void SceneManager::SetTransformations(
    glm::vec3 scaleXYZ,
    float XrotationDegrees,
    float YrotationDegrees,
    float ZrotationDegrees,
    glm::vec3 positionXYZ)
{
    glm::mat4 modelView;
    glm::mat4 scale;
    glm::mat4 rotationX;
    glm::mat4 rotationY;
    glm::mat4 rotationZ;
    glm::mat4 translation;

    scale = glm::scale(scaleXYZ);
    rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
    rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
    rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
    translation = glm::translate(positionXYZ);

    modelView = translation * rotationX * rotationY * rotationZ * scale;

    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setMat4Value(g_ModelName, modelView);
    }
}

/***********************************************************
 *  SetShaderColor()
 ***********************************************************/
void SceneManager::SetShaderColor(
    float redColorValue,
    float greenColorValue,
    float blueColorValue,
    float alphaValue)
{
    glm::vec4 currentColor;
    currentColor.r = redColorValue;
    currentColor.g = greenColorValue;
    currentColor.b = blueColorValue;
    currentColor.a = alphaValue;

    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setIntValue(g_UseTextureName, false);
        m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
    }
}

/***********************************************************
 *  SetShaderTexture()
 ***********************************************************/
void SceneManager::SetShaderTexture(std::string textureTag)
{
    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setIntValue(g_UseTextureName, true);
        int textureID = FindTextureSlot(textureTag);
        m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
    }
}

/***********************************************************
 *  SetTextureUVScale()
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
    }
}

/***********************************************************
 *  SetShaderMaterial()
 ***********************************************************/
void SceneManager::SetShaderMaterial(std::string materialTag)
{
    if (m_objectMaterials.size() > 0)
    {
        OBJECT_MATERIAL material;
        bool bReturn = FindMaterial(materialTag, material);
        if (bReturn == true)
        {
            m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
            m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
            m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
            m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
            m_pShaderManager->setFloatValue("material.shininess", material.shininess);
        }
    }
}

/**************************************************************/
/*** STUDENT SCENE (below)                                   ***/
/**************************************************************/

/***********************************************************
 *  PrepareScene()
 *  Load all meshes once.
 ***********************************************************/
void SceneManager::PrepareScene()
{
    // Load each mesh only once regardless of draw count
    m_basicMeshes->LoadPlaneMesh();
    m_basicMeshes->LoadBoxMesh();
    m_basicMeshes->LoadCylinderMesh();
    m_basicMeshes->LoadSphereMesh();
    m_basicMeshes->LoadConeMesh();
}

/***********************************************************
 *  RenderScene()
 *  Draw the scene: floor + round table + bowl + spoon + bottle
 ***********************************************************/
void SceneManager::RenderScene()
{
    // Convenience lambdas for cleaner draws
    auto drawPlane = [&](glm::vec3 s, glm::vec3 p, glm::vec4 c)
        {
            SetTransformations(s, 0.f, 0.f, 0.f, p);
            SetShaderColor(c.r, c.g, c.b, c.a);
            m_basicMeshes->DrawPlaneMesh();
        };

    auto drawBox = [&](glm::vec3 s, glm::vec3 p, glm::vec4 c, float rx = 0.f, float ry = 0.f, float rz = 0.f)
        {
            SetTransformations(s, rx, ry, rz, p);
            SetShaderColor(c.r, c.g, c.b, c.a);
            m_basicMeshes->DrawBoxMesh();
        };

    auto drawCylinder = [&](glm::vec3 s, glm::vec3 p, glm::vec4 c, float rx = 0.f, float ry = 0.f, float rz = 0.f)
        {
            SetTransformations(s, rx, ry, rz, p);
            SetShaderColor(c.r, c.g, c.b, c.a);
            m_basicMeshes->DrawCylinderMesh();
        };

    auto drawSphere = [&](glm::vec3 s, glm::vec3 p, glm::vec4 c, float rx = 0.f, float ry = 0.f, float rz = 0.f)
        {
            SetTransformations(s, rx, ry, rz, p);
            SetShaderColor(c.r, c.g, c.b, c.a);
            m_basicMeshes->DrawSphereMesh();
        };

    auto drawCone = [&](glm::vec3 s, glm::vec3 p, glm::vec4 c, float rx = 0.f, float ry = 0.f, float rz = 0.f)
        {
            SetTransformations(s, rx, ry, rz, p);
            SetShaderColor(c.r, c.g, c.b, c.a);
            m_basicMeshes->DrawConeMesh();
        };

    // Colors
    const glm::vec4 white = { 1.00f, 1.00f, 1.00f, 1.0f };
    const glm::vec4 lightGray = { 0.92f, 0.92f, 0.95f, 1.0f };
    const glm::vec4 tableBrown = { 0.55f, 0.35f, 0.20f, 1.0f };
    const glm::vec4 darkBrown = { 0.40f, 0.26f, 0.14f, 1.0f };
    const glm::vec4 steel = { 0.78f, 0.78f, 0.80f, 1.0f };
    const glm::vec4 glassBlue = { 0.70f, 0.86f, 0.98f, 1.0f };
    const glm::vec4 floorGray = { 0.85f, 0.85f, 0.85f, 1.0f };
    const glm::vec4 shadowGray = { 0.12f, 0.12f, 0.12f, 1.0f };

    // Slight lift so objects sit on the plane cleanly
    const float tableY = 0.15f;

    /**********************
     * FLOOR (large plane)
     **********************/
    drawPlane(glm::vec3(30.f, 1.f, 20.f), glm::vec3(0.f, 0.f, 0.f), floorGray);

    /**********************
     * ROUND TABLE
     * - central leg (cylinder)
     * - round top (cylinder squashed)
     **********************/
     // Leg
    drawCylinder(glm::vec3(0.4f, 2.2f, 0.4f), glm::vec3(0.f, tableY + 1.1f, 0.f), darkBrown);

    // Round top (slim, wide cylinder)
    drawCylinder(glm::vec3(5.0f, 0.18f, 5.0f), glm::vec3(0.f, tableY + 2.25f, 0.f), tableBrown);

    // A very subtle darker rim
    drawCylinder(glm::vec3(5.05f, 0.02f, 5.05f), glm::vec3(0.f, tableY + 2.35f, 0.f), darkBrown);

    /**********************
     * BOWL (centered)
     * - shallow body (cylinder)
     * - thin rim (slightly larger cylinder)
     **********************/
     // Body
    drawCylinder(glm::vec3(1.2f, 0.22f, 1.2f), glm::vec3(-0.6f, tableY + 2.50f, 0.2f), lightGray);

    // Inner �shadow� disk to fake cavity
    drawCylinder(glm::vec3(1.05f, 0.01f, 1.05f), glm::vec3(-0.6f, tableY + 2.61f, 0.2f), shadowGray);

    // Rim
    drawCylinder(glm::vec3(1.25f, 0.03f, 1.25f), glm::vec3(-0.6f, tableY + 2.63f, 0.2f), white);

    /**********************
     * SPOON (near bowl)
     * - handle: thin cylinder
     * - head: flattened sphere
     **********************/
     // Handle
    drawCylinder(glm::vec3(0.05f, 0.75f, 0.05f),
        glm::vec3(0.4f, tableY + 2.33f, 0.55f),
        steel,
        0.f, 0.f, 12.f);

    // Head (flattened sphere)
    drawSphere(glm::vec3(0.22f, 0.06f, 0.28f),
        glm::vec3(0.65f, tableY + 2.33f, 0.55f),
        steel);

    /**********************
     * BOTTLE (right side)
     * - body: cylinder
     * - neck: slimmer cylinder
     * - cap: small cone
     **********************/
     // Body
    drawCylinder(glm::vec3(0.25f, 0.70f, 0.25f),
        glm::vec3(1.6f, tableY + 2.70f, -0.2f),
        glassBlue);

    // Neck
    drawCylinder(glm::vec3(0.12f, 0.25f, 0.12f),
        glm::vec3(1.6f, tableY + 3.18f, -0.2f),
        glassBlue);

    // Cap
    drawCone(glm::vec3(0.14f, 0.20f, 0.14f),
        glm::vec3(1.6f, tableY + 3.45f, -0.2f),
        white);
}
