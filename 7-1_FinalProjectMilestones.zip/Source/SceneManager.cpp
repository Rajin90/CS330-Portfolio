///////////////////////////////////////////////////////////////////////////////
// SceneManager.cpp

///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

namespace
{
    const char* g_ModelName = "model";
    const char* g_ColorValueName = "objectColor";
    const char* g_TextureValueName = "objectTexture";
    const char* g_UseTextureName = "bUseTexture";
}

/***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_basicMeshes = new ShapeMeshes();
    m_loadedTextures = 0;
}

SceneManager::~SceneManager()
{
    delete m_basicMeshes;
}

/***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
    int w, h, c;
    stbi_set_flip_vertically_on_load(true);
    unsigned char* img = stbi_load(filename, &w, &h, &c, 0);
    if (!img) return false;

    GLuint tex;
    glGenTextures(1, &tex);
    glBindTexture(GL_TEXTURE_2D, tex);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    if (c == 3)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, w, h, 0, GL_RGB, GL_UNSIGNED_BYTE, img);
    else
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, img);

    glGenerateMipmap(GL_TEXTURE_2D);
    stbi_image_free(img);

    m_textureIDs[m_loadedTextures].ID = tex;
    m_textureIDs[m_loadedTextures].tag = tag;
    m_loadedTextures++;
    return true;
}

/***********************************************************/
void SceneManager::BindGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
    }
}

int SceneManager::FindTextureSlot(std::string tag)
{
    for (int i = 0; i < m_loadedTextures; i++)
        if (m_textureIDs[i].tag == tag) return i;
    return -1;
}

/***********************************************************/
void SceneManager::SetTransformations(glm::vec3 s, float rx, float ry, float rz, glm::vec3 p)
{
    glm::mat4 model =
        glm::translate(p) *
        glm::rotate(glm::radians(rx), glm::vec3(1, 0, 0)) *
        glm::rotate(glm::radians(ry), glm::vec3(0, 1, 0)) *
        glm::rotate(glm::radians(rz), glm::vec3(0, 0, 1)) *
        glm::scale(s);

    m_pShaderManager->setMat4Value(g_ModelName, model);
}

void SceneManager::SetShaderColor(float r, float g, float b, float a)
{
    m_pShaderManager->setIntValue(g_UseTextureName, false);
    m_pShaderManager->setVec4Value(g_ColorValueName, glm::vec4(r, g, b, a));
}

void SceneManager::SetShaderTexture(std::string tag)
{
    int slot = FindTextureSlot(tag);
    m_pShaderManager->setIntValue(g_UseTextureName, true);
    m_pShaderManager->setSampler2DValue(g_TextureValueName, slot);
}

void SceneManager::SetTextureUVScale(float u, float v)
{
    m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
}

/***********************************************************/
void SceneManager::PrepareScene()
{
    m_basicMeshes->LoadPlaneMesh();
    m_basicMeshes->LoadCylinderMesh();
    m_basicMeshes->LoadTorusMesh();
    m_basicMeshes->LoadBoxMesh();
    m_basicMeshes->LoadConeMesh();

    CreateGLTexture("Assets/textures/WoodFloor064_1K-JPG_Color.jpg", "tableTexture");
}

/***********************************************************/
void SceneManager::RenderScene()
{
    BindGLTextures();
    glm::vec3 s, p;

    // TABLE
    s = glm::vec3(28, 0.1f, 18);
    p = glm::vec3(0, 0, 0);
    SetTransformations(s, 0, 0, 0, p);
    SetShaderTexture("tableTexture");
    SetTextureUVScale(4, 4);
    m_basicMeshes->DrawPlaneMesh();

    // LAPTOP BASE
    s = glm::vec3(5.4f, 0.1f, 3.4f);
    p = glm::vec3(0, 0.1f, -4.5f);
    SetTransformations(s, 0, 0, 0, p);
    SetShaderColor(0.06f, 0.06f, 0.06f, 1);
    m_basicMeshes->DrawBoxMesh();

    // KEYBOARD
    s = glm::vec3(5.0f, 0.02f, 3.0f);
    p = glm::vec3(0, 0.18f, -4.5f);
    SetTransformations(s, 0, 0, 0, p);
    SetShaderColor(0.12f, 0.12f, 0.12f, 1);
    m_basicMeshes->DrawBoxMesh();

    // SCREEN FRAME
    s = glm::vec3(5.4f, 3.8f, 0.12f);
    p = glm::vec3(0, 3.0f, -6.3f);
    SetTransformations(s, -70, 0, 0, p);
    SetShaderColor(0.05f, 0.05f, 0.05f, 1);
    m_basicMeshes->DrawBoxMesh();

    // SCREEN GLOW
    s = glm::vec3(4.8f, 3.2f, 0.05f);
    p = glm::vec3(0, 3.1f, -6.4f);
    SetTransformations(s, -70, 0, 0, p);
    SetShaderColor(0.28f, 0.48f, 1.0f, 1);
    m_basicMeshes->DrawBoxMesh();

    // CUP
    s = glm::vec3(0.9f, 1.5f, 0.9f);
    p = glm::vec3(4, 1.5f, 1.4f);
    SetTransformations(s, 0, 0, 0, p);
    SetShaderColor(0.96f, 0.96f, 0.96f, 1);
    m_basicMeshes->DrawCylinderMesh();

    // HANDLE
    s = glm::vec3(0.55f);
    p = glm::vec3(5.0f, 1.5f, 1.4f);
    SetTransformations(s, 0, 0, 90, p);
    SetShaderColor(0.96f, 0.96f, 0.96f, 1);
    m_basicMeshes->DrawTorusMesh();

    // PAPER
    s = glm::vec3(4.0f, 0.02f, 2.8f);
    p = glm::vec3(-5, 0.03f, 2);
    SetTransformations(s, 0, 0, -10, p);
    SetShaderColor(0.98f, 0.98f, 0.98f, 1);
    m_basicMeshes->DrawBoxMesh();

    // PENCIL
    s = glm::vec3(0.15f, 2.8f, 0.15f);
    p = glm::vec3(-2.7f, 1.4f, 2.3f);
    SetTransformations(s, 90, 0, 0, p);
    SetShaderColor(1, 0.82f, 0.05f, 1);
    m_basicMeshes->DrawCylinderMesh();

    // TIP
    s = glm::vec3(0.18f, 0.45f, 0.18f);
    p = glm::vec3(-2.7f, 0.05f, 2.3f);
    SetTransformations(s, -90, 0, 0, p);
    SetShaderColor(0.3f, 0.15f, 0.05f, 1);
    m_basicMeshes->DrawConeMesh();
}